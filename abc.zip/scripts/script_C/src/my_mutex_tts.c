#include "../headers/my_mutex_tts.h"

int my_mutex_init(my_mutex_t *my_mutex)
{
    // TODO
    return 0;
}

int my_mutex_destroy(my_mutex_t *my_mutex)
{
    // TODO
    return 0;
}

int my_mutex_lock(my_mutex_t *my_mutex)
{
    // TODO
    return 0;
}

int my_mutex_unlock(my_mutex_t *my_mutex)
{
    // TODO
    return 0;
}